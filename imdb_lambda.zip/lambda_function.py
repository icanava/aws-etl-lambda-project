import boto3, io, pandas as pd

s3 = boto3.client('s3')

# ——— S3 paths ———
SRC_BUCKET = 'my-etl-movie-bucket'                 # raw bucket
SRC_KEY    = 'raw/imdb_movies.csv'                 # raw file
DST_BUCKET = 'my-etl-movie-bucket'                 # clean bucket
DST_KEY    = 'final-clean/final_very_clean_fixed.csv'  # clean file

def handler(event, context):
    """Main Lambda entry point."""
    # 1) Download raw CSV from S3
    obj = s3.get_object(Bucket=SRC_BUCKET, Key=SRC_KEY)
    df  = pd.read_csv(io.BytesIO(obj['Body'].read()))

    # 2) Clean / transform
    df_clean = (df
        .replace({'Revenue (Millions)': {'': None, 'N/A': None}})
        .dropna(subset=['Revenue (Millions)'])
        .astype({'Revenue (Millions)': 'float'}))

    # 3) Upload cleaned CSV back to S3
    out_buf = io.StringIO()
    df_clean.to_csv(out_buf, index=False)
    s3.put_object(Bucket=DST_BUCKET, Key=DST_KEY, Body=out_buf.getvalue())

    # 4) Return simple status
    return {'status': 'success', 'rows': len(df_clean)}

